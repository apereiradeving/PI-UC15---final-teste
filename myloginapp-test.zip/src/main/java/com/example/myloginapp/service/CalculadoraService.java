package com.example.myloginapp.service;

public class CalculadoraService {

    public int somar(int a, int b) {
        return a + b;
    }
}
