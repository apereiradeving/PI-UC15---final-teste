package com.example.myloginapp.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

public class CalculadoraServiceTest {

    @Test
    public void testSomar() {
        CalculadoraService calc = new CalculadoraService();
        int resultado = calc.somar(3, 4);
        assertEquals(7, resultado, "3 + 4 deve ser 7");
    }
}
